
const fechaNacimento = new Date(2001, 06, 29); 

const lista = [nombre="Juan Mateo", edad=21, isDesarrolador= true, fechaNacimiento= new Date(2001, 05, 29), libroFavorito={
titulo: "Los Juegos del Hambre", 
autor: "Suzanne Collins",
fecha: new Date(2008, 08, 14),
url: "https://www.amazon.com/-/es/Suzanne-Collins/dp/6073807848/ref=sr_1_1?keywords=los+juegos+del+hambre&qid=1665697555&qu=eyJxc2MiOiI0LjQ2IiwicXNhIjoiMy45NiIsInFzcCI6IjMuNjQifQ%3D%3D&sprefix=los+juegos+%2Caps%2C467&sr=8-1",
}]


const arr = ["Adrian","Erika","Emma","Juan"];
const setFamilia = new Set(arr);

setFamilia.add("Juan");
setFamilia.add("Javascript");

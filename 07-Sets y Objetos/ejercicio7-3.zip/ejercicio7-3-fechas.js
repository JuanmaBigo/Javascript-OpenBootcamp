let fechaHoy = new Date();

let fechaNac = new Date(2001,5,29);

let esMasTarde = fechaHoy > fechaNac;

let diaNac = fechaNac.getDate();

let mesNac = fechaNac.getMonth()+1;

let anioNac = fechaNac.getFullYear()



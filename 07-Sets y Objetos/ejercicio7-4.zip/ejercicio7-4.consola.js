const edad = prompt("cual es tu edad?");
const edad_num = Number(edad);

let alturaEncm = 173;
let alturaEnm = 1.73;
let peso = 52.5;
let pesoRedondAbajo = Math.ceil(alturaEnm);
let alturaRedondArriba = Math.floor(peso);
let maxValorJS = (Number.MAX_VALUE+1 === Number.MAX_VALUE)


let factorial = 1;

for (let i = 10; i > 1; i--) {
    factorial *= i;
}

console.log(factorial);